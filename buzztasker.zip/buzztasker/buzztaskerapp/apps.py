from django.apps import AppConfig


class BuzztaskerappConfig(AppConfig):
    name = 'buzztaskerapp'
